"""
Lab 3: Program 1 (Questions 1 - 5)

"""

def main():
    request = "Enter number of tickets required: "
    tickets = get_number_from_user(request)
    full_price = get_ticket_price(tickets, 15)
    discount = get_discount(tickets, full_price)
    display_ticket_price(tickets, full_price, discount)
    
def display_ticket_price(tickets, price, discount):    
    pass

def get_gst_amount(price):
    pass

def get_discount(number_of_tickets, total_price):
    pass

def get_ticket_price(number_of_tickets, ticket_price):
    pass

def get_number_from_user(prompt):
    pass

main()








