"""
Lab 5:
"""

def main():
    print_longest_word(['fish', 'barrel', 'like', 'shooting', 'in', 'a'])
    print_longest_word(['cat', 'the', 'the', 'bag', 'let', 'out', 'of'])
    print_longest_word(['the', 'the', 'bag', 'let', 'out', 'of', 'cat'])

def print_longest_word(word_list):
    pass

main()








