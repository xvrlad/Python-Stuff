"""
Lab 5:
"""

def main():
    print_numbers(10, 25)
    print()
    print_numbers(25, 20)
    print()
    print_numbers(9, 33)
    print()

def print_numbers(number1, number2):
    pass

main()








