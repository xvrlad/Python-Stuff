"""
Draws an ox pattern
Date-written: Semester One, 2020.
Author:
"""

def main():
    print_ox_xo_pattern(5, 4)
    print()
    
def print_ox_xo_pattern(number_of_rows, number_of_columns):

main()
    

    
            
    
		
    
    
