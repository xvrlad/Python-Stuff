"""
Draws a mirrored right-angle triangle pattern
Date-written: Semester 1, 2020.
Author:
"""

def main():
    print_mirrored_right_angle_triangle(4, '*')
    print_mirrored_right_angle_triangle(4, 1)
    
def print_mirrored_right_angle_triangle(number_of_rows, style):

main()
