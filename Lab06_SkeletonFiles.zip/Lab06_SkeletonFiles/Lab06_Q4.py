"""
Lab 6:

"""

def main():
    numbers_list = [31, 636, 2042, 40, 447]
    print(numbers_list)
    increase_decrease(numbers_list)
    print(numbers_list)
    print()

    numbers_list = [11, 4559, 241, 99, 100]
    print(numbers_list)
    increase_decrease(numbers_list)
    print(numbers_list)
    print()

    numbers_list = [101, 45594, 1241, 9, 92]
    print(numbers_list)
    increase_decrease(numbers_list)
    print(numbers_list)

def increase_decrease(numbers_list):
    pass

main()








