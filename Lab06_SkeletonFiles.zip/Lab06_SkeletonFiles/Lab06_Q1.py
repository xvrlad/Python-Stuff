"""
Lab 6:

"""

def main():
    numbers1 = [1, 4, 6, 2, 9, 8]
    numbers2 = [4, 0, 8, 1, 9, 7, 1]
    print(numbers1)
    print(numbers2)
    print(have_same_start_total(numbers1, numbers2))
    print()

    numbers1 = [1, 4, 5, 2, 9, 8]
    numbers2 = [4, 0, 8, 1, 9, 7, 1]
    print(numbers1)
    print(numbers2)
    print(have_same_start_total(numbers1, numbers2))
    print()

    numbers1 = [1, 4, 5]
    numbers2 = [4, 0, 8, 1, 9, 7, 1]
    print(numbers1)
    print(numbers2)
    print(have_same_start_total(numbers1, numbers2))

def have_same_start_total(list1, list2):
    pass

main()








