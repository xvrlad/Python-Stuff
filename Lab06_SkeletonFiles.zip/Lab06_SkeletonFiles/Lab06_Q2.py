"""
Lab 6:

"""

def main():
    numbers = [9, 0, 2, 5, 6, 4, 5]
    print(numbers)
    swap_elements(numbers, 2, 4)
    print(numbers)
    print()

    numbers = [9, 0, 9, 5, 6, 6, 5]
    print(numbers)
    swap_elements(numbers, 9, 6)
    print(numbers)
    print()

    numbers = [9, 8, 11, 5, 6, 7, 5]
    print(numbers)
    swap_elements(numbers, 6, 4)
    print(numbers)

def swap_elements(numbers_list, number1, number2):
    pass

main()








