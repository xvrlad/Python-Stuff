""" Use this file to develop and test your Assignment 4 function 7"""

#--------------------------------------------------
# 7777777777777777777777777777777777777777777777777
# get_next_words_dict()
#--------------------------------------------------
def get_next_words_dict(text):
    pass

def main():
    print_header(7, "get_next_words_dict()")
    text = 'Easy come easy go go easy go easy'
    next_words_dict = get_next_words_dict(text)
    print_dict_in_key_order(next_words_dict)
    print()

    text = 'happy joy happy happy joy joy'
    next_words_dict = get_next_words_dict(text)
    print_dict_in_key_order(next_words_dict)

#--------------------------------------------------
# A helper function
#--------------------------------------------------
def print_dict_in_key_order(a_dict):
    all_keys = list(a_dict.keys())
    all_keys.sort()
    for key in all_keys:
        print(key, ":", a_dict[key])
#--------------------------------------------------
#Print header lines
#--------------------------------------------------
def print_header(number, text):
    text = str(number) + ". " + text
    print("-" * 30)
    print(str(number) * 30)
    print(text)
    print("-" * 30)

main()
