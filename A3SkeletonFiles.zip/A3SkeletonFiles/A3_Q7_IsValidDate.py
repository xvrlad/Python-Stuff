""" Assignment 3 function 7"""

def main():
    print_header(7, "is_a_valid_date()")
    print("1.", is_a_valid_date("January 21"))
    print("2.", is_a_valid_date("Auust 3"))
    print("3.", is_a_valid_date(" June   15B "))
    print("4.", is_a_valid_date("February 0"))
    print("5.", is_a_valid_date(" December 3K1"))
    print("6.", is_a_valid_date("January 28 6"))
    print("7.", is_a_valid_date(" January 6  "))
    print("8.", is_a_valid_date(" January   "))
#--------------------------------------------------
# 7777777777777777777777777777777777777777777777777
# Returns True if the parameter string is a
# valid date, otherwise returns False
#--------------------------------------------------
def is_a_valid_date(date_str):
    month_names = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    days_in_month = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    
#--------------------------------------------------
# Print header lines
#--------------------------------------------------
def print_header(number, text):
    text = str(number) + ". " + text
    print("-" * 30)
    print(str(number) * 30)
    print(text)
    print("-" * 30)

main()
