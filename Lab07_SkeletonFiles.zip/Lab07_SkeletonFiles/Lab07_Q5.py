"""
Lab 7:

"""

def main():
    number_repeated = get_number_of_unique_repeats("Lab07Q05_1.txt")
    print(number_repeated)
    print()

    print(get_number_of_unique_repeats("Lab07Q05_2.txt"))
    print()

    print(get_number_of_unique_repeats("Lab07Q05_3.txt"))


def get_number_of_unique_repeats(filename):
    pass

main()








