"""
Lab 7:

"""

def main():
    message = ("For this question you are required to submit\n" +
            "ONE line of text, the line numbered 100 from the\n" +
            "output file created by this program.")
    print(message)

    write_without_blank_lines("Lab07Q06_in.txt", "Lab07Q06_out.txt")


def write_without_blank_lines(filename_in, filename_out):
    pass

main()








