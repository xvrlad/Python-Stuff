"""
Lab 7:

"""

def main():
    number_same = get_length_same("Lab07Q04_1.txt", "Lab07Q04_2.txt")
    print(number_same)
    print()

    print(get_length_same("Lab07Q04_3.txt", "Lab07Q04_4.txt"))
    print()

    print(get_length_same("Lab07Q04_5.txt", "Lab07Q04_6.txt"))
    
def get_length_same(filename1, filename2):
    pass

main()








