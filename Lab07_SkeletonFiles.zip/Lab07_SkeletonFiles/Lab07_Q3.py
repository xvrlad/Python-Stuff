"""
Lab 7:

"""

def main():
    filename = "Lab07Q03_1.txt"
    print(get_biggest_difference(filename))
    print()

    filename = "Lab07Q03_2.txt"
    print(get_biggest_difference(filename))


def get_biggest_difference(filename):
    pass

main()








