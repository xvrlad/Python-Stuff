"""
Lab 4:
"""

def main():
    print_even_numbers(6, 20)
    print()

    print_even_numbers(7, 20)
    print()

    print_even_numbers(-9, 5)
    print()

    print_even_numbers(21, 4)

def print_even_numbers(first_num, last_num):
    pass

main()








