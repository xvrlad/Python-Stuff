"""
Lab 4:
"""

def main():
    result = test_string("Antonid")
    print(result)
    print(test_string("Anatonis"))
    print(test_string("PD"))

def test_string(phrase):
    pass

main()








