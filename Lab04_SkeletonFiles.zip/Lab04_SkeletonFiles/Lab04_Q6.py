"""
Lab 4:
"""

def main():
    result = test_number(33)
    print(result)
    print(test_number(28))
    print(test_number(30))

def test_number(value):
    pass

main()








