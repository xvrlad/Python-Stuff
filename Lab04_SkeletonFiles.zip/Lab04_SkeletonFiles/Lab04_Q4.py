"""
Lab 4:
"""

def main():
    result = remove_spaces("1 5 67 88")
    print(result)

    print(remove_spaces("programming  is such fun,  fun,   fun"))
    print()

    print(remove_spaces("1 5 67 88    "))
    print()

    print(remove_spaces("    1 5    67 88"))

def remove_spaces(phrase):
    pass

main()








