"""
Lab 4:
"""

def main():
    letter = get_letter("Dreams")
    print(letter)

    print(get_letter("programming"))

def get_letter(word):
    pass

main()








