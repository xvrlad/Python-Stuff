"""
Lab 8 Ex 4
Author:
Date: May, 2020
This program reads in a file of baby names and
prints a list of baby names by initial letter
"""
def main():
    filename = get_filename_from_user()
    names = get_list_of_names(filename)
    baby_name_dictionary = create_baby_names_dictionary(names)
    display_baby_names(baby_name_dictionary)

def get_filename_from_user():
    filename = input("Enter a filename: ")
    return filename
    
def get_list_of_names(filename):
    # You complete this

def create_baby_names_dictionary(names_list): 
    # You complete this

def display_baby_names(baby_names_dict):
    # You complete this

main()
