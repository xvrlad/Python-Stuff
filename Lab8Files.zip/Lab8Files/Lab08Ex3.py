"""
Lab 8 Ex 3
Author:
Date: May, 2020
This program produces a summary of the top 10 baby names
"""
def main():
    filename = get_filename_from_user()
    names = get_list_of_names(filename)
    name_count_dictionary = create_names_count_dictionary(names)
    produce_name_counts_report(name_count_dictionary)

def get_filename_from_user():
    filename = input("Enter a filename: ")
    return filename

def get_list_of_names(filename):
    # You complete this

def create_names_count_dictionary(names_list): 
    # You complete this

def produce_name_counts_report(name_counts_dict):
    # You complete this

main()
